/**
 * 
 */
/**
 * @author PABLO
 *
 */
package fotos;