package Visual;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.TextAttribute;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Map;
import java.awt.Desktop;
import java.awt.Dimension;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JOptionPane;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class VentanaSolucionLugar {
	String [] solucion;
	public VentanaSolucionLugar(String [] sol) {
		this.solucion=sol;
	}
	public JPanel VentanaSol(JFrame f, JPanel panelAnterior){
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		
		JLabel resultados = new JLabel("Resultados");
		resultados.setForeground(Color.WHITE);
		resultados.setFont(new Font("Elephant", Font.PLAIN, 50));
		resultados.setBounds(480, 30, 585, 72);
		contentPane.add(resultados);
		
		JButton volver = new JButton("");
		volver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.setVisible(false);
				panelAnterior.setVisible(true);
			}
		});
		volver.setIcon(new ImageIcon(VentanaPropiedades.class.getResource("/fotos/botonVolver.png")));
		volver.setBounds(30, 30, 76, 72);
		volver.setContentAreaFilled(false);
		volver.setBorderPainted(false);
		contentPane.add(volver);
		
		
		int c = 0;
		for (int i = 0; i < solucion.length; i++) {
			
			if(solucion[i].isEmpty()) {
				break;
			}
			//System.out.println("ENTRA");
			JLabel sol = new JLabel(solucion[i]);
			sol.setForeground(Color.WHITE);
			sol.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 14));
			sol.setBounds(c, 0, 300, 720);
			contentPane.add(sol);
			c+=300;
			
			
			
		}
		
		
		
		
		
		
		JLabel fondoMenu = new JLabel("");
		fondoMenu.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 14));
		fondoMenu.setIcon(new ImageIcon(VentanaPropiedades.class.getResource("/fotos/agua.jpg")));
		fondoMenu.setBounds(0, -28, 1280, 720);
		contentPane.add(fondoMenu);
		return contentPane;
	}
}
