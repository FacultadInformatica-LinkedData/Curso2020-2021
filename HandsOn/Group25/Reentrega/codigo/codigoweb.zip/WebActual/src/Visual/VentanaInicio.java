package Visual;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import modelo.Consultas;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaInicio {
	public static Consultas consulta;
	
	public static void main(String[] args) {
		JFrame primeraVentana = new JFrame("Calidad del agua Santander");
		primeraVentana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		primeraVentana.setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaInicio.class.getResource("/fotos/santander-montes-nieve.jpg")));
		primeraVentana.setBounds(0, 0, 1280, 720);
		primeraVentana.setSize(1280, 720);
		primeraVentana.setLocation((Toolkit.getDefaultToolkit().getScreenSize().width  - primeraVentana.getSize().width) / 2, (Toolkit.getDefaultToolkit().getScreenSize().height - primeraVentana.getSize().height) / 2);
		JPanel pan = ventanaBienvenida(primeraVentana);
		primeraVentana.add(pan);
		primeraVentana.setResizable(false);
		primeraVentana.setVisible(true);
		consulta = new Consultas();
	}

	public VentanaInicio() {

	}
	public static JPanel ventanaBienvenida(JFrame f){
		JPanel p = new JPanel();
		p.setBorder(new EmptyBorder(5, 5, 5, 5));
		p.setLayout(null);
		p.setVisible(true);
		
		JButton botonEmpezar = new JButton("Inicio");
		botonEmpezar.setForeground(Color.BLACK);
		botonEmpezar.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		botonEmpezar.setBounds(563, 360, 131, 58);
		botonEmpezar.setVisible(true);
		botonEmpezar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				p.setVisible(false);
				VentanaBusqueda ventBusq = new VentanaBusqueda();
				JPanel panelAux = ventBusq.ventanaBusquedaInicial(f);
				f.add(panelAux);
			}
		});
		p.add(botonEmpezar);

		JLabel fondoInicio = new JLabel("");
		fondoInicio.setIcon(new ImageIcon(VentanaInicio.class.getResource("/fotos/santander-montes-nieve.jpg")));
		fondoInicio.setBounds(0, 0, 1280, 720);
		p.add(fondoInicio);
		return p;
	}

}
