package Visual;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaBusqueda {

public VentanaBusqueda() {
		
	}
	public JPanel ventanaBusquedaInicial(JFrame f){
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		JButton botonpropiedades = new JButton("Propiedades del Agua");
		botonpropiedades.setForeground(Color.BLUE);
		botonpropiedades.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		botonpropiedades.setBounds(240, 360, 300, 58);
		botonpropiedades.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.setVisible(false);
				VentanaPropiedades w1 = new VentanaPropiedades();
				JPanel panelAux = w1.ventanaPropiedades(f, contentPane);
				f.add(panelAux);
			}
		});
		contentPane.add(botonpropiedades);
		
		
		JButton botonlugar = new JButton("Lugar");
		botonlugar.setForeground(Color.BLUE);
		botonlugar.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		botonlugar.setBounds(740, 360, 246, 58);
		botonlugar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.setVisible(false);
				VentanaLugar w1 = new VentanaLugar();
				JPanel panelAux = w1.ventanaLugar(f, contentPane);
				f.add(panelAux);
			}
		});
		contentPane.add(botonlugar);
		
		
		JLabel fondoMenu = new JLabel("");
		fondoMenu.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 14));
		fondoMenu.setIcon(new ImageIcon(VentanaBusqueda.class.getResource("/fotos/santanderBusqueda.jpg")));
		fondoMenu.setBounds(0, -28, 1280, 720);
		contentPane.add(fondoMenu);
		return contentPane;
	}
}
