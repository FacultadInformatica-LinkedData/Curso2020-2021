//Physical Samples
package Visual;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.apache.jena.sparql.function.library.leviathan.sec;

import Visual.*;

public class VentanaLugar {
	JTextField lugarT;
	String [] solucion;
	
	public VentanaLugar() {

	}
	public JPanel ventanaLugar(JFrame f, JPanel panelAnterior){
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		JButton volver = new JButton("");
		volver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.setVisible(false);
				panelAnterior.setVisible(true);
			}
		});
		volver.setIcon(new ImageIcon(VentanaLugar.class.getResource("/fotos/botonVolver.png")));
		volver.setBounds(30, 30, 76, 72);
		volver.setContentAreaFilled(false);
		volver.setBorderPainted(false);
		contentPane.add(volver);

		JLabel physSamp = new JLabel("Lugares");
		physSamp.setForeground(Color.WHITE);
		physSamp.setFont(new Font("Elephant", Font.PLAIN, 50));
		physSamp.setBounds(380, 30, 585, 72);
		contentPane.add(physSamp);
		
		
		lugarT = new JTextField();
		lugarT.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		lugarT.setBounds(640, 340, 150, 29);
		contentPane.add(lugarT);
		lugarT.setColumns(10);
		
		
		
		////////
		
		JButton botonBuscar = new JButton("Buscar");
		botonBuscar.setForeground(Color.BLUE);
		botonBuscar.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		botonBuscar.setBounds(640, 520, 112, 33);
		botonBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String lugar = lugarT.getText();
				if(lugar.equals("")) lugar = null;		
			
				String res = VentanaInicio.consulta.consultaLugar(lugar);
				if(res==null || res.isEmpty()){
					JOptionPane.showMessageDialog(null, "No hay resultados","Error", JOptionPane.WARNING_MESSAGE);
				}else{
					contentPane.setVisible(false);
					solucion=VentanaInicio.consulta.resultadoventana2(res);
					VentanaSolucionLugar w1 = new VentanaSolucionLugar(solucion);
					JPanel panelAux = w1.VentanaSol(f, contentPane);
					f.add(panelAux);
					
				}
			}
		});
		contentPane.add(botonBuscar);
		
		JLabel lugarl = new JLabel("LUGAR");
		lugarl.setForeground(Color.WHITE);
		lugarl.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		lugarl.setBounds(640, 320, 300, 14);
		contentPane.add(lugarl);

		
		
		
		JLabel fondoMenu = new JLabel("");
		fondoMenu.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 14));
		fondoMenu.setIcon(new ImageIcon(VentanaLugar.class.getResource("/fotos/agua.jpg")));
		fondoMenu.setBounds(0, -28, 1280, 720);
		contentPane.add(fondoMenu);
		return contentPane;
	}
}
