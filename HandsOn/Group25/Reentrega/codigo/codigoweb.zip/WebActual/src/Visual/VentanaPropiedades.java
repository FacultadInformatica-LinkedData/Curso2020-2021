//Physical Samples
package Visual;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.apache.jena.sparql.function.library.leviathan.sec;

import Visual.*;

public class VentanaPropiedades {
	JTextField Al, Pb, Cr, Fe, CloroLibre, N, olor, color, sabor,  ecoli, clos, clori, aero, ph, turb, cond, oxi;
	String solucion;
	
	public VentanaPropiedades() {

	}
	public JPanel ventanaPropiedades(JFrame f, JPanel panelAnterior){
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		JButton volver = new JButton("");
		volver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.setVisible(false);
				panelAnterior.setVisible(true);
			}
		});
		volver.setIcon(new ImageIcon(VentanaPropiedades.class.getResource("/fotos/botonVolver.png")));
		volver.setBounds(30, 30, 76, 72);
		volver.setContentAreaFilled(false);
		volver.setBorderPainted(false);
		contentPane.add(volver);

		JLabel physSamp = new JLabel("Propiedades del Agua");
		physSamp.setForeground(Color.WHITE);
		physSamp.setFont(new Font("Elephant", Font.PLAIN, 50));
		physSamp.setBounds(380, 30, 585, 72);
		contentPane.add(physSamp);
		
		
		Al = new JTextField();
		Al.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		Al.setBounds(140, 150, 80, 29);
		contentPane.add(Al);
		Al.setColumns(10);
		
		Pb = new JTextField();
		Pb.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		Pb.setBounds(340, 150, 80, 29);
		contentPane.add(Pb);
		Pb.setColumns(10);
		
		Cr = new JTextField();
		Cr.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		Cr.setBounds(540, 150, 80, 29);
		contentPane.add(Cr);
		Cr.setColumns(10);
		
		Fe = new JTextField();
		Fe.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		Fe.setBounds(740, 150, 80, 29);
		contentPane.add(Fe);
		Fe.setColumns(10);
		
		CloroLibre = new JTextField();
		CloroLibre.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		CloroLibre.setBounds(940, 150, 80, 29);
		contentPane.add(CloroLibre);
		CloroLibre.setColumns(10);
		
		N = new JTextField();
		N.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		N.setBounds(1140, 150, 80, 29);
		contentPane.add(N);
		N.setColumns(10);
		
		//////
		
		olor = new JTextField();
		olor.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		olor.setBounds(240, 250, 80, 29);
		contentPane.add(olor);
		olor.setColumns(10);
		
		color = new JTextField();
		color.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		color.setBounds(640, 250, 80, 29);
		contentPane.add(color);
		color.setColumns(10);
		
		sabor = new JTextField();
		sabor.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		sabor.setBounds(1040, 250, 80, 29);
		contentPane.add(sabor);
		sabor.setColumns(10);
		
		//////
		
		ecoli = new JTextField();
		ecoli.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		ecoli.setBounds(340, 350, 80, 29);
		contentPane.add(ecoli);
		ecoli.setColumns(10);
		
		clos = new JTextField();
		clos.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		clos.setBounds(540, 350, 80, 29);
		contentPane.add(clos);
		clos.setColumns(10);
		
		clori = new JTextField();
		clori.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		clori.setBounds(740, 350, 80, 29);
		contentPane.add(clori);
		clori.setColumns(10);
		
		aero = new JTextField();
		aero.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		aero.setBounds(940, 350, 80, 29);
		contentPane.add(aero);
		aero.setColumns(10);
		
		////////////
		
		ph = new JTextField();
		ph.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		ph.setBounds(340, 450, 80, 29);
		contentPane.add(ph);
		ph.setColumns(10);
		
		turb = new JTextField();
		turb.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		turb.setBounds(540, 450, 80, 29);
		contentPane.add(turb);
		turb.setColumns(10);
		
		cond = new JTextField();
		cond.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		cond.setBounds(740, 450, 80, 29);
		contentPane.add(cond);
		cond.setColumns(10);
		
		oxi = new JTextField();
		oxi.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 12));
		oxi.setBounds(940, 450, 80, 29);
		contentPane.add(oxi);
		oxi.setColumns(10);
		
		////////
		
		JButton botonBuscar = new JButton("Buscar");
		botonBuscar.setForeground(Color.BLUE);
		botonBuscar.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		botonBuscar.setBounds(640, 520, 112, 33);
		botonBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String al = Al.getText();
				if(al.equals("")) al = null;	
				
				String pb = Pb.getText();;
				if(pb.equals("")) pb = null;	
				
				String cr = Cr.getText();
				if(cr.equals("")) cr = null;	
								
				String fe = Fe.getText();
				if(fe.equals("")) fe = null;
				
				String cloro = CloroLibre.getText();
				if(cloro.equals("")) cloro = null;	
					
				String n = N.getText();
				if(n.equals("")) n = null;
				
				//////
				
				String solor = olor.getText();
				if(solor.equals("")) solor = null;	
				
				String scolor = color.getText();;
				if(scolor.equals("")) scolor = null;	
				
				String ssabor = sabor.getText();
				if(ssabor.equals("")) ssabor = null;	
				
				////////////
				
				String secoli = ecoli.getText();
				if(secoli.equals("")) secoli = null;
				
				String sclos = clos.getText();
				if(sclos.equals("")) sclos = null;	
								
				String sclori = clori.getText();
				if(sclori.equals("")) sclori = null;
				
				String saero = aero.getText();
				if(saero.equals("")) saero = null;
				
				/////////////////////
				
				String sph = ph.getText();
				if(sph.equals("")) sph = null;	
								
				String stur = turb.getText();
				if(stur.equals("")) stur = null;	
				
				String scond = cond.getText();
				if(scond.equals("")) scond = null;	
								
				String soxi = oxi.getText();
				if(soxi.equals("")) soxi = null;
				
			
				String res = VentanaInicio.consulta.consultatodo(al, pb, cr, fe, cloro, n, solor, scolor, ssabor, secoli,
						sclos, sclori, saero, sph, stur, scond, soxi);
				if(res==null || res.isEmpty()){
					JOptionPane.showMessageDialog(null, "No hay resultados","Error", JOptionPane.WARNING_MESSAGE);
				}else{
					contentPane.setVisible(false);
					solucion=VentanaInicio.consulta.resultadoventana1(res);
					VentanaSolucionPropiedades w1 = new VentanaSolucionPropiedades(solucion);
					JPanel panelAux = w1.VentanaSol(f, contentPane);
					f.add(panelAux);
					
				}
			}
		});
		contentPane.add(botonBuscar);
		
		JLabel Al = new JLabel("Al");
		Al.setForeground(Color.WHITE);
		Al.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		Al.setBounds(140, 130, 30, 14);
		contentPane.add(Al);

		JLabel Pb = new JLabel("Pb");
		Pb.setForeground(Color.WHITE);
		Pb.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		Pb.setBounds(340, 130, 30, 14);
		contentPane.add(Pb);
		
		JLabel Cr = new JLabel("Cr");
		Cr.setForeground(Color.WHITE);
		Cr.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		Cr.setBounds(540, 130, 30, 14);
		contentPane.add(Cr);
		
		JLabel Fe = new JLabel("Fe");
		Fe.setForeground(Color.WHITE);
		Fe.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		Fe.setBounds(740, 130, 30, 14);
		contentPane.add(Fe);
		
		JLabel CloroLibre = new JLabel("CloroLibre");
		CloroLibre.setForeground(Color.WHITE);
		CloroLibre.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		CloroLibre.setBounds(940, 130, 100, 14);
		contentPane.add(CloroLibre);
		
		JLabel N = new JLabel("N");
		N.setForeground(Color.WHITE);
		N.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		N.setBounds(1140, 130, 203, 14);
		contentPane.add(N);
		
		//240, 350, 80, 29
		
		JLabel olor = new JLabel("Olor");
		olor.setForeground(Color.WHITE);
		olor.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		olor.setBounds(240, 220, 100, 14);
		contentPane.add(olor);

		JLabel color = new JLabel("Color");
		color.setForeground(Color.WHITE);
		color.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		color.setBounds(640, 220, 100, 14);
		contentPane.add(color);
		
		JLabel sabor = new JLabel("Sabor");
		sabor.setForeground(Color.WHITE);
		sabor.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		sabor.setBounds(1040, 220, 100, 14);
		contentPane.add(sabor);
		
		///////////////////
		
		JLabel ecoli = new JLabel("Ecoli");
		ecoli.setForeground(Color.WHITE);
		ecoli.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		ecoli.setBounds(340, 320, 200, 14);
		contentPane.add(ecoli);
		
		JLabel clos = new JLabel("clostridiumPerfringes");
		clos.setForeground(Color.WHITE);
		clos.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		clos.setBounds(540, 320, 200, 14);
		contentPane.add(clos);
		
		JLabel clori = new JLabel("bacteriasColiformes");
		clori.setForeground(Color.WHITE);
		clori.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		clori.setBounds(740, 320, 200, 14);
		contentPane.add(clori);
		
		JLabel aero = new JLabel("bacteriasAerobias");
		aero.setForeground(Color.WHITE);
		aero.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		aero.setBounds(940, 320, 200, 14);
		contentPane.add(aero);
		
		//////////////
		
		JLabel ph = new JLabel("pH");
		ph.setForeground(Color.WHITE);
		ph.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		ph.setBounds(340, 420, 200, 14);
		contentPane.add(ph);
		
		JLabel turb = new JLabel("Turbidez");
		turb.setForeground(Color.WHITE);
		turb.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		turb.setBounds(540, 420, 200, 14);
		contentPane.add(turb);
		
		JLabel cond = new JLabel("Conductividad");
		cond.setForeground(Color.WHITE);
		cond.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		cond.setBounds(740, 420, 200, 14);
		contentPane.add(cond);
		
		JLabel oxi = new JLabel("Oxidabilidad");
		oxi.setForeground(Color.WHITE);
		oxi.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 16));
		oxi.setBounds(940, 420, 200, 14);
		contentPane.add(oxi);
		
		
		JLabel fondoMenu = new JLabel("");
		fondoMenu.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 14));
		fondoMenu.setIcon(new ImageIcon(VentanaPropiedades.class.getResource("/fotos/agua.jpg")));
		fondoMenu.setBounds(0, -28, 1280, 720);
		contentPane.add(fondoMenu);
		return contentPane;
	}
}
