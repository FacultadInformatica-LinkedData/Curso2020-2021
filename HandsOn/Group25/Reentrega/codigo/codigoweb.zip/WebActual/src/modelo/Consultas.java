package modelo;



import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QueryParseException;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.rdf.model.StmtIterator;
import org.apache.jena.riot.RDFDataMgr;

import com.github.andrewoma.dexx.collection.LinkedList;

public class Consultas {
	
	//cargamos los datos
	Model datos = RDFDataMgr.loadModel("datos/output.nt"); ///cargar los datos

	//En la peticion quiero generar una consulta a sparql
	public String consultatodo (String al, String pb, String cr, String fe, String cloroLibre, String ni, 
			String olor, String color, String sabor, 
			String ecoli, String clostridiumPerfringere, String bacteriasColiformes, String bacteriasAerobias, String ph,
			String turbidez, String conductividad, String oxidabilidad ) {
		
		String peticion="";	
		
		if (al!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:Al ?d. FILTER(?d = \""+al+"\") }";
		}
				
		if (pb!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:Pb ?d. FILTER(?d = \""+pb+"\") }";
		}
				
		if (cr!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:Cr ?d. FILTER(?d = \""+cr+"\") }";
		}
				
		if (fe!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:Fe ?d. FILTER(?d = \""+fe+"\") }";
		}
		
		if (cloroLibre!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:cloroLibre ?d. FILTER(?d = \""+cloroLibre+"\") }"; 
		}
		
		if (ni!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:Ni ?d. FILTER(?d = \""+ni+"\") }"; 
		}
		
		
		if (ecoli!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:eColi ?d. FILTER(?d = \""+ecoli+"\") }"; 
		}
				
		if (clostridiumPerfringere!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:ClostridiumPerfringes ?d. FILTER(?d = \""+clostridiumPerfringere+"\") }";
		}
				
		if (bacteriasColiformes!=null) {

			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:bacteriasColiformes ?d. FILTER(?d = \""+bacteriasColiformes+"\") }";
		}
				
		if (bacteriasAerobias!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:bacteriasAerobias ?d. FILTER(?d = \""+bacteriasAerobias+"\") }";
		}
		
		if (olor!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:olor ?d. FILTER(?d = \""+olor+"\") }";
		}
				
		if (color!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:color ?d. FILTER(?d = \""+color+"\") }";
		}
				
		if (sabor!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:sabor ?d. FILTER(?d = \""+sabor+"\") }";
		}
		
		if (ph!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:pH ?d. FILTER(?d = \""+ph+"\") }";
		}
				
		if (turbidez!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:turbidez ?d. FILTER(?d = \""+turbidez+"\") }"; 
		}
				
		if (conductividad!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:conductividad ?d. FILTER(?d = \""+conductividad+"\") }";
		}
				
		if (oxidabilidad!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:oxidabilidad ?d. FILTER(?d = \""+oxidabilidad+"\") }";
		}
		return peticion;
	}
	
	public String consultaWqObservation (String fecha) {
		
		String peticion = "";
		
		if (fecha!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:fecha ?d. FILTER(?d = \""+fecha+"\") }";
		}
		return peticion;
	}	
	
	public String consultaLugar (String lugar) {
		
		String peticion = "";
		
		if (lugar!=null) {
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:PuntoMuestreo ?d. FILTER(?d = \""+lugar+"\") }";
		}
		return peticion;
	}	
		
	public String resultadoventana1 (String peticion) {
		
		String resultado = "<html>";
		
		try {
			/**
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?al WHERE {?x ds:Al ?al}";
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ?p ?o. FILTER(?p = ds:Pb) }";
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?x ?al WHERE {{?x ds:oxidabilidad ?d. FILTER (?d = \"0.60000\")} UNION {?x ds:Al ?al}}";
			ESTA ES LA BUENA
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> SELECT ?q WHERE { ?q ds:oxidabilidad ?d. FILTER(?d = \"0.60000\") }";
			peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> PREFIX ns: <http://datos.santander.es/api/datos/medida_calidad_agua/> SELECT ?p ?o WHERE { ?s ?p ?o. FILTER(?s = ns:N4-13-002180) }";
			N4-13-002180
			*/
			//Ejecuto la query para obtener los sensores
			Query qpeticion = QueryFactory.create(peticion);
			QueryExecution ejecucion = QueryExecutionFactory.create(qpeticion, datos);
			ResultSet resultados = ejecucion.execSelect();
			
			RDFNode sujeto=null;
			RDFNode objeto=null;
			String datosvalor="";
			
			
			while (resultados.hasNext()) {
				
				QuerySolution solucion = resultados.nextSolution();
				//realizo una consulta para obtener todos los datos por cada sensor
				//predicado=solucion.get("o");
				//System.out.println(objeto.asResource().getModel().toString());
				//System.out.println(objeto.asResource().getNameSpace());
				//System.out.println(predicado.asResource().getLocalName());
				//System.out.println(solucion.get("q").asResource().getLocalName());
				
				peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> PREFIX ns: <http://datos.santander.es/api/datos/medida_calidad_agua/> SELECT ?p ?o WHERE { ?s ?p ?o. FILTER(?s = ns:"+solucion.get("q").asResource().getLocalName()+") }";
				
				//ejecutamos la query
				Query qpeticion2 = QueryFactory.create(peticion);
				QueryExecution ejecucion2 = QueryExecutionFactory.create(qpeticion2, datos);
				ResultSet resultados2 = ejecucion2.execSelect();
				
				
				
				while(resultados2.hasNext()) {
					QuerySolution solucion2 = resultados2.nextSolution();
					
					sujeto=solucion2.get("p");
					objeto=solucion2.get("o");
				
				
				if(sujeto.asResource().getLocalName().equals("PuntoMuestreo")) {
					
						
						datosvalor+=objeto.toString()+" ";	
					
			}
				
			}
				resultado+=datosvalor+ "<p>";
				
				//resultado+=datosnombre+"\n"+datosvalor+"\n";
				
				datosvalor="";
			
			}
			resultado+="</html>";
			ejecucion.close();
				//System.out.println(resultado);		
		}
			
		//capturar errores de sintaxis en consulta 
			catch(QueryParseException e){
				System.out.println("Consulta mal construida: " + e.getMessage());
				System.out.println("Linea :" + e.getLine() + "Columna :" + e.getColumn());
			}
		return resultado;
	}
	
	public String [] resultadoventana2 (String peticion) {
		
		
		String [] resultado = new String[10];
		int tamanio = 0;
		int i  = 0;
		try {
			
			
			Query qpeticion = QueryFactory.create(peticion);
			QueryExecution ejecucion = QueryExecutionFactory.create(qpeticion, datos);
			ResultSet resultados = ejecucion.execSelect();
			
			while(resultados.hasNext()) {
				resultados.nextSolution();
				++tamanio; 
			}
			//System.out.println("TAMANIO:"+tamanio);
			resultado = new String[tamanio];
			
			//lo pongo a cero
			ejecucion = QueryExecutionFactory.create(qpeticion, datos);
			resultados = ejecucion.execSelect();
			
			RDFNode sujeto=null;
			RDFNode objeto=null;
					
			
			while (resultados.hasNext()) {
				resultado[i]="<html>";
				QuerySolution solucion = resultados.nextSolution();
								
				peticion="PREFIX ds: <http://datos.santander.es/api/datos/calidad_agua/#> PREFIX ns: <http://datos.santander.es/api/datos/medida_calidad_agua/> SELECT ?p ?o WHERE { ?s ?p ?o. FILTER(?s = ns:"+solucion.get("q").asResource().getLocalName()+") }";
				
				Query qpeticion2 = QueryFactory.create(peticion);
				QueryExecution ejecucion2 = QueryExecutionFactory.create(qpeticion2, datos);
				ResultSet resultados2 = ejecucion2.execSelect();
				
				
				
				
				while(resultados2.hasNext()) {
					QuerySolution solucion2 = resultados2.nextSolution();
					
					sujeto=solucion2.get("p");
					objeto=solucion2.get("o");
				
				
				if(sujeto.asResource().getLocalName().equals("bacteriasColiformes") || sujeto.asResource().getLocalName().equals("pH") || sujeto.asResource().getLocalName().equals("Fe") 
						|| sujeto.asResource().getLocalName().equals("Cr") || sujeto.asResource().getLocalName().equals("Ni") || sujeto.asResource().getLocalName().equals("cloroLibre") 
						|| sujeto.asResource().getLocalName().equals("oxidabilidad") ||sujeto.asResource().getLocalName().equals("color") || sujeto.asResource().getLocalName().equals("turbidez") 
						|| sujeto.asResource().getLocalName().equals("Al") || sujeto.asResource().getLocalName().equals("clostridiumPerfringes") 
						||sujeto.asResource().getLocalName().equals("bacteriasAerobias") || sujeto.asResource().getLocalName().equals("eColi") || sujeto.asResource().getLocalName().equals("conductividad")
						|| sujeto.asResource().getLocalName().equals("Pb") || sujeto.asResource().getLocalName().equals("sabor") || sujeto.asResource().getLocalName().equals("olor")  || sujeto.asResource().getLocalName().equals("PuntoMuestreo")){
						
							
						resultado[i]+=sujeto.asResource().getLocalName()+":"+objeto.toString()+"<p>";
						
					
			}
				
					if(sujeto.asResource().getLocalName().equals("fecha")){
						resultado[i]+=sujeto.asResource().getLocalName()+":"+objeto.toString().substring(0, 10)+"<p>";
					
						
						
							
				}
					
			}
				
			
			
			resultado[i]+="</html>";
			//System.out.println(resultado[i]);
			i++;
			}
			
			ejecucion.close();
				//System.out.println(resultado);		
		}
			
		//capturar errores de sintaxis en consulta 
			catch(QueryParseException e){
				System.out.println("Consulta mal construida: " + e.getMessage());
				System.out.println("Linea :" + e.getLine() + "Columna :" + e.getColumn());
			}
		return resultado;
			}
}
