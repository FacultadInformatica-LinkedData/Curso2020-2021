#!/usr/bin/python

from SPARQLWrapper import SPARQLWrapper, JSON
import sys
import re
import rdflib

#Lista de consultas predefinidas
consulta0="""PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> PREFIX owl: <http://www.w3.org/2002/07/owl#> SELECT DISTINCT ?Provincia WHERE { ?Provincia rdf:type <http://www.wsdl.org/grupo17/ontology/Provincia> . ?Provincia owl:sameAs <https://www.wikidata.org/wiki/Q24004405> }"""

consulta1="""SELECT * WHERE { ?w ?b ?v }"""

predefConsults=(consulta0,consulta1)
#Comprueba que al llamar al script solo se haya introducido 1 argumento
def numArgum(integ):
    correcto=False
    if len(integ)==2:
        correcto=True
    return correcto

def ConsultaSPARQL(valor):
    pathOntology="./AppResources/ontology.ttl"
    ii = buscaenteros(valor)
    consulta=" "
    if ii > -1 :
        consulta = predefConsults[ii]       
    else:
        consulta = valor
    #En local:
    g = rdflib.Graph()
    g.parse(pathOntology, format = rdflib.util.guess_format(pathOntology))
    results=g.query(consulta)
    #Online:
    #sparql = SPARQLWrapper("https://github.com/isa43/Curso2020-2021/tree/master/HandsOn/Group17/ontology/ontology.ttl")
    #sparql.setQuery(consulta)
    #sparql.setReturnFormat(JSON)
    #results = sparql.query().convert()
    return results

#funcion que comprueba si se ha introducido una consulta o un numero
def buscaenteros(cadena):
    ret=-1
    f=re.search("^\d",cadena)
    if f!=None and len(cadena)==1:
        ret=int(cadena)
    return ret

#main
if numArgum(sys.argv)==False:
    print("Help: ~$ python3.8 runconsults.py 'su consulta SPARQL'|[Entero]")
else:
    print("Correcto. Consultando",sys.argv[1])
    results = ConsultaSPARQL(sys.argv[1])
    for result in results:
        print(result)
    print(len(results)) 



